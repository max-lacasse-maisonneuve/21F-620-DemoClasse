# Exercice cours 1 - Personnalisation de la page

1. Créez un fichier `main.js` et intégrez-le correctement dans l'entête votre page HTML. (N'oubliez pas l'attribut `defer`)
2. Créer une variable `nom` et `prenom` et affectez-y votre nom et prénom.
3. Sélectionnez individuellement tous les endroits ayant du texte `Placer le nom complet ICI` et remplacez le texte à l'aide de vos variables `nom` et `prenom`.
4. Révisez les notes de cours sur les sélecteurs pour vous aider.

**Vous n'avez pas à remettre ce travail**
