console.log("Ça marche");

const titreHTML = document.querySelector("h1");
let nom = "Maxime";
titreHTML.textContent = `Bonjour, ${nom}`;
